import React from "react";

const CourseList = () => {
  return (
    <section id="courses" className="courses">
      <h2>Available Courses</h2>
      <ul>
        <li>Introduction to AI</li>
        <li>Advanced JavaScript</li>
        <li>Data Science Fundamentals</li>
      </ul>
    </section>
  );
};

export default CourseList;
