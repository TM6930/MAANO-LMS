import React from "react";

function TeacherDashboard() {
    return (
        <div className="dashboard-container">
            <h2>Welcome, Teacher!</h2>
            <p>Manage your classes, grade students, and track performance.</p>
            {/* Teacher-related functionalities */}
        </div>
    );
}

export default TeacherDashboard;

import React, { useEffect } from 'react';

function InteractiveVideo() {
    useEffect(() => {
        // This script loads the H5P content dynamically, make sure you've linked to the H5P libraries.
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/npm/h5p-standalone@1.0.0/h5p-standalone.min.js";
        script.async = true;
        document.body.appendChild(script);

        script.onload = () => {
            // Initialize the H5P content when the script loads
            H5P.init('#h5p-container', {
                content_id: 'your-content-id',  // Replace with the actual content ID
            });
        };
    }, []);

    return (
        <div className="interactive-video">
            <div id="h5p-container"></div>
        </div>
    );
}

export default InteractiveVideo;

import React, { useState, useEffect } from 'react';

function StudentDashboard() {
    const [analytics, setAnalytics] = useState(null);
    const userData = { /* Example data, replace with real data */ };

    // Function to call backend for AI analytics
    const getAnalytics = async (userData) => {
        const response = await fetch('http://localhost:5000/get-analytics', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ userData }),
        });
        const data = await response.json();
        return data.insights;
    };

    // Call AI analytics when the component is mounted
    useEffect(() => {
        const fetchAnalytics = async () => {
            const result = await getAnalytics(userData);
            setAnalytics(result);
        };

        fetchAnalytics();
    }, [userData]);

    return (
        <div className="dashboard-container">
            <h2>Welcome, Student!</h2>
            {analytics ? (
                <div>
                    <h3>Your Insights:</h3>
                    <pre>{JSON.stringify(analytics, null, 2)}</pre>
                </div>
            ) : (
                <p>Loading analytics...</p>
            )}
        </div>
    );
}

export default StudentDashboard;
