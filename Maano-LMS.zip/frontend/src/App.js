import React from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import CourseList from './components/CourseList';
import VideoPlayer from './components/VideoPlayer';
import Chat from './components/Chat';
import Footer from './components/Footer';

const App = () => {
  return (
    <div className="app">
      <Header />
      <Dashboard />
      <CourseList />
      <VideoPlayer />
      <Chat />
      <Footer />
    </div>
  );
};

export default App;
